(() => {
  'use strict';

  const boot = () => {
    if (!window.Vue) return;

    const { createApp } = window.Vue;

    createApp({
      data() {
        return {
          ready: false,
          activeCard: '',
          reduceMotion: window.matchMedia('(prefers-reduced-motion: reduce)').matches
        };
      },
      mounted() {
        requestAnimationFrame(() => {
          this.ready = true;
        });
      },
      methods: {
        onPointerMove(event) {
          if (this.reduceMotion || event.pointerType === 'touch') return;
          const x = Math.max(0, Math.min(100, (event.clientX / window.innerWidth) * 100));
          const y = Math.max(0, Math.min(100, (event.clientY / window.innerHeight) * 100));
          document.documentElement.style.setProperty('--mx', `${x}%`);
          document.documentElement.style.setProperty('--my', `${y}%`);
        },
        resetPointer() {
          document.documentElement.style.setProperty('--mx', '50%');
          document.documentElement.style.setProperty('--my', '45%');
        }
      }
    }).mount('#app');
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot, { once: true });
  } else {
    boot();
  }
})();
